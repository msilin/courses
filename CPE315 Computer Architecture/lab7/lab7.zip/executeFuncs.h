#include "lab7.h"

/*R type inst*/
void add(unsigned int registers[32], Instruction* instruction);
void addu(unsigned int registers[32], Instruction* instruction);
void sub(unsigned int registers[32], Instruction* instruction);
void subu(unsigned int registers[32], Instruction* instruction);
void executeAnd(unsigned int registers[32], Instruction* instruction);
void nor(unsigned int registers[32], Instruction* instruction);
void ExecuteOr(unsigned int registers[32], Instruction* instruction);
void ExecuteXor(unsigned int registers[32], Instruction* instruction);
void sll(unsigned int registers[32], Instruction* instruction);
void srl(unsigned int registers[32], Instruction* instruction);
void sra(unsigned int registers[32], Instruction* instruction);
void sllv(unsigned int registers[32], Instruction* instruction);
void srlv(unsigned int registers[32], Instruction* instruction);
void srav(unsigned int registers[32], Instruction* instruction);
void slt(unsigned int registers[32], Instruction* instruction);
void sltu(unsigned int registers[32], Instruction* instruction);
void syscall(unsigned int registers[32], Instruction* instruction, MultiCycleState* ms);
/*R type jumps*/
void jr(unsigned int registers[32], Instruction* instruction);
void jalr(unsigned int registers[32], Instruction* instruction);

/*I type inst*/
void addi(unsigned int registers[32], Instruction* instruction);
void addiu(unsigned int registers[32], Instruction* instruction);
void andi(unsigned int registers[32], Instruction* instruction);
void ori(unsigned int registers[32], Instruction* instruction);
void xori(unsigned int registers[32], Instruction* instruction);
void slti(unsigned int registers[32], Instruction* instruction);
void sltiu(unsigned int registers[32], Instruction* instruction);
/*I type branches*/
void beq(unsigned int registers[32], Instruction* instruction);
void bne(unsigned int registers[32], Instruction* instruction);
/*I type load and stores*/
void lb(unsigned int registers[32], Instruction* instruction);
void lbu(unsigned int registers[32], Instruction* instruction);
void lh(unsigned int registers[32], Instruction* instruction);
void lhu(unsigned int registers[32], Instruction* instruction);
void lui(unsigned int registers[32], Instruction* instruction);
void lw(unsigned int registers[32], Instruction* instruction);


/*J type instructions*/
void jal(unsigned int registers[32], Instruction* instruction);
void j(unsigned int registers[32], Instruction* instruction);




void runRType(unsigned int registers[32], Instruction* instruction, MultiCycleState* ms);
void runIType(unsigned int registers[32], Instruction* instruction, MultiCycleState* ms);
void runJType(unsigned int registers[32], Instruction* instruction, MultiCycleState* ms);
void printRegisters(unsigned int registers[32], MultiCycleState* ms);

void incrementRTypeClocks(unsigned int registers[32], Instruction* instruction, MultiCycleState* ms);
void incrementITypeClocks(Instruction* instruction, MultiCycleState* ms);
