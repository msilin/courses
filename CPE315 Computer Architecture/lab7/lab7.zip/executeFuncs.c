#include <stdio.h>
#include <stdlib.h>
#include "executeFuncs.h"
/* This function takes in an array of registers(unsigned ints) and a pointer to an instruction struct. 
 * This function sets the rd register to the rs + rt registers. 
 * This function has a return type of void.
 */
void add(unsigned int registers[32], Instruction* instruction){
   instruction->ALUout=registers[instruction->rs]+registers[instruction->rt];
   instruction->regtoWrite=&registers[instruction->rd];
}
void addi(unsigned int registers[32], Instruction* instruction){
   instruction->regtoWrite=&registers[instruction->rt];
   instruction->ALUout = registers[instruction->rs]+instruction->sign_ext_imm;
}
void addiu(unsigned int registers[32], Instruction* instruction){
   instruction->regtoWrite=&registers[instruction->rt];
   instruction->ALUout =registers[instruction->rs]+instruction->immediate;
}
//Addu unsigned - not sure how this is different than add. something about no exception for overflows
void addu(unsigned int registers[32], Instruction* instruction){
   instruction->regtoWrite=&registers[instruction->rt];
   instruction->ALUout =registers[instruction->rs]+registers[instruction->rt];
}
// not sure if he wants us to use a trap for overflow
void sub(unsigned int registers[32], Instruction* instruction){
   instruction->regtoWrite=&registers[instruction->rt];
   instruction->ALUout =registers[instruction->rs]-registers[instruction->rt];
}
void subu(unsigned int registers[32], Instruction* instruction){
   instruction->regtoWrite=&registers[instruction->rt];
   instruction->ALUout =registers[instruction->rs]-registers[instruction->rt];
}
/*-------------------------------------------------------------*/
void executeAnd(unsigned int registers[32], Instruction* instruction){
   instruction->regtoWrite=&registers[instruction->rd];
   instruction->ALUout =registers[instruction->rs]&registers[instruction->rt];
}
/* This function takes in an array of registers(unsigned ints) and a pointer to an instruction struct. 
 * This function sets the rt register to rs registers & with the immediate field zero extended 
 * This function has a return type of void.
 */
void andi(unsigned int registers[32], Instruction* instruction){
   instruction->regtoWrite=&registers[instruction->rt];
   instruction->ALUout =registers[instruction->rs]&instruction->immediate;
}
void nor(unsigned int registers[32], Instruction* instruction){
   instruction->regtoWrite=&registers[instruction->rt];
   instruction->ALUout =~(registers[instruction->rs]|registers[instruction->rt]);
}
void executeOr(unsigned int registers[32], Instruction* instruction){
   instruction->regtoWrite=&registers[instruction->rd];
   instruction->ALUout =registers[instruction->rs]|registers[instruction->rt];
}
void ori(unsigned int registers[32], Instruction* instruction){
   instruction->regtoWrite=&registers[instruction->rt];
   instruction->ALUout =registers[instruction->rs]|instruction->immediate;
   //printf("\n\nalout\n\n%d:",instruction->ALUout);
   //printf("\n\nrs\n\n%d:",registers[instruction->rs]);
   //printf("\n\nimmed\n\n%d:",instruction->immediate);
}
void executeXor(unsigned int registers[32], Instruction* instruction){
   instruction->regtoWrite=&registers[instruction->rt];
   instruction->ALUout =registers[instruction->rs]^registers[instruction->rt];
}
void xori(unsigned int registers[32], Instruction* instruction){
   instruction->regtoWrite=&registers[instruction->rt];
   instruction->ALUout = registers[instruction->rs]^instruction->immediate;
}
/*-------------------------------------------------------------*/
/* This function takes in an array of registers(unsigned ints) and a pointer to an instruction struct. 
 * This function sets the rd register to rt register left logically shifted by the shamt field.
 * This function has a return type of void.
 */
void sll(unsigned int registers[32], Instruction* instruction){

   instruction->regtoWrite=&registers[instruction->rt]; 
   instruction->ALUout = registers[instruction->rt]<<instruction->shamt;
}
void srl(unsigned int registers[32], Instruction* instruction){
   instruction->regtoWrite=&registers[instruction->rd];
   instruction->ALUout = registers[instruction->rt]>>instruction->shamt;
}
void sra(unsigned int registers[32], Instruction* instruction){
   // This function is different from SRL in that it keeps the signed bit
   int signBit= registers[instruction->rt] & 0x80000000;
   int i;
   instruction->regtoWrite=&registers[instruction->rd];
   instruction->ALUout = registers[instruction->rt];
   for (i=0; i < instruction->shamt ;i++){
      instruction->ALUout = registers[instruction->rd]>>1;
      instruction->ALUout = registers[instruction->rd] | signBit;
      signBit= signBit>>1;
   }
}
void sllv(unsigned int registers[32], Instruction* instruction){
    instruction->regtoWrite=&registers[instruction->rt];
    instruction->ALUout = registers[instruction->rt]<<registers[instruction->rs];
}
void srlv(unsigned int registers[32], Instruction* instruction){
   instruction->regtoWrite=&registers[instruction->rt]; 
   instruction->ALUout =registers[instruction->rt]>>registers[instruction->rs];
}
void srav(unsigned int registers[32], Instruction* instruction){
   // This function is different from SRL in that it keeps the signed bit
   instruction->regtoWrite=&registers[instruction->rd];
   instruction->ALUout = registers[instruction->rt];
   int signBit= registers[instruction->rt] & 0x80000000;
   int i;
   for (i=0; i < registers[instruction->rs]; i++)
   {
      instruction->ALUout  = instruction->ALUout >>1;
      instruction->ALUout  = instruction->ALUout  | signBit;
      signBit= signBit>>1;
   }
}
/* This function takes in an array of registers(unsigned ints) and a pointer to an instruction struct. 
 * This function sets the rd register to 1 if the rs register is less than the rt register
 * Otherwise the rd register is set to 0.
 * This function has a return type of void.
 */
void slt(unsigned int registers[32], Instruction* instruction){
   instruction->regtoWrite=&registers[instruction->rd];
   if (registers[instruction->rs]<registers[instruction->rt])
   {
      instruction->ALUout = 1;
   }
   else {
      instruction->ALUout = 0;
   }
}

void slti(unsigned int registers[32], Instruction* instruction){
   instruction->regtoWrite=&registers[instruction->rt];
   if (registers[instruction->rs] < instruction->sign_ext_imm)
   {
      instruction->ALUout = 1;
   }
   else {
      instruction->ALUout = 0;
   }
}

void sltiu(unsigned int registers[32], Instruction* instruction){
   instruction->regtoWrite=&registers[instruction->rt];
   if (registers[instruction->rs] < instruction->immediate)
   {
      instruction->ALUout = 1;
   }
   else {
      instruction->ALUout = 0;
   }   
}

void sltu(unsigned int registers[32], Instruction* instruction){
   instruction->regtoWrite=&registers[instruction->rd];
   if (registers[instruction->rs]<registers[instruction->rt])
   {
      instruction->ALUout = 1;
   }
   else {
      instruction->ALUout = 0;
   }
}
/* This function takes in an array of registers(unsigned ints) and a pointer to an instruction struct. 
 * This function takes the branch if the rs and rt registers are equal. Otherwise the pc gets incremented as it 
 * normally would.
 * This function has a return type of void.
 */
void beq(unsigned int registers[32], Instruction* instruction){
   if (registers[instruction->rs] == registers[instruction->rt])
   {
      instruction->pc= instruction->branch_addr;
      instruction->regtoWrite=&registers[0];
      instruction->ALUout =0;
   }
}
void bne(unsigned int registers[32], Instruction* instruction){
   if ( registers[instruction->rs] != registers[instruction->rt])
   {
      instruction->pc=instruction->branch_addr;
      instruction->regtoWrite=&registers[0];
      instruction->ALUout =0;
   }
}
void blt(unsigned int registers[32], Instruction* instruction){
   if ( registers[instruction->rs] < registers[instruction->rt])
   {
      instruction->pc=instruction->branch_addr;
      instruction->regtoWrite=&registers[0];
      instruction->ALUout =0;
   }
}
void bgt(unsigned int registers[32], Instruction* instruction){
   if ( registers[instruction->rs] > registers[instruction->rt])
   {
      instruction->pc=instruction->branch_addr;
      instruction->regtoWrite=&registers[0];
      instruction->ALUout =0;
   }
}
void ble(unsigned int registers[32], Instruction* instruction){
   if ( registers[instruction->rs] <= registers[instruction->rt])
   {
      instruction->pc=instruction->branch_addr;
      instruction->regtoWrite=&registers[0];
      instruction->ALUout =0;
   }
}
void bge(unsigned int registers[32], Instruction* instruction){
   if ( registers[instruction->rs] >= registers[instruction->rt])
   {
      instruction->pc=instruction->branch_addr;
      instruction->regtoWrite=&registers[0];
      instruction->ALUout =0;
   }
}
/* This function takes in an array of registers(unsigned ints) and a pointer to an instruction struct. 
 * This function changes the program counter to the 26 bit index left shifted by 2. 
 * This function has a return type of void.
 */
void j(unsigned int registers[32], Instruction* instruction){
   instruction->pc=instruction->branch_addr-4;//sub 4 here due to for loop incrementing pc
   instruction->regtoWrite=&registers[0];
   instruction->ALUout =0;
}

void jal(unsigned int registers[32], Instruction* instruction){
   registers[31]= instruction->pc+4;
   instruction->pc=instruction->branch_addr-4;//sub 4 here due to for loop incrementing pc
   
   instruction->regtoWrite=&registers[0];
   instruction->ALUout =0;
}
void jr(unsigned int registers[32], Instruction* instruction){
   instruction->pc= registers[instruction->rs]-4;
   instruction->regtoWrite=&registers[0];
   instruction->ALUout =0;
}
void jalr(unsigned int registers[32], Instruction* instruction){
   registers[31]= instruction->pc+4;
   instruction->pc= registers[instruction->rs]-4;//sub 4 here due to for loop incrementing pc
   instruction->regtoWrite=&registers[0];
   instruction->ALUout =0;
}
/*-------------------------------------------------------------*/

void lb(unsigned int registers[32], Instruction* instruction){
   instruction->regtoWrite=&registers[instruction->rt];
   instruction->ALUout = (registers[instruction->rs] + instruction->sign_ext_imm)/4;


}
void lbu(unsigned int registers[32], Instruction* instruction){
   instruction->regtoWrite=&registers[instruction->rt];
   instruction->ALUout = (registers[instruction->rs] + instruction->sign_ext_imm)/4;
}
void lh(unsigned int registers[32], Instruction* instruction){
   instruction->regtoWrite=&registers[instruction->rt];
   instruction->ALUout = (registers[instruction->rs] + instruction->sign_ext_imm)/4;
   
}
void lhu(unsigned int registers[32], Instruction* instruction){
   instruction->regtoWrite=&registers[instruction->rt];
   instruction->ALUout=(registers[instruction->rs] + instruction->sign_ext_imm)/4;
}
void lui(unsigned int registers[32], Instruction* instruction){
   instruction->regtoWrite=&registers[instruction->rt];
   instruction->ALUout = instruction->sign_ext_imm << 16;
}
/* This function takes in an array of registers(unsigned ints) a pointer to an instruction struct, and the memory array. 
 * This function sets the rt register to the mem[rs register + the sign extended immediate field].
 * This function has a return type of void.
 */
void lw(unsigned int registers[32], Instruction* instruction){
   instruction->regtoWrite=&registers[instruction->rt];
   instruction->ALUout=(registers[instruction->rs] + instruction->sign_ext_imm)/4;
}
// I'm not sure about these last 2 , they're pseudo instructions
void li(unsigned int registers[32], Instruction* instruction){
   instruction->regtoWrite=&registers[instruction->rt];
   instruction->ALUout =(instruction->immediate) & 0x0000FFFF;
}
void la(unsigned int registers[32], Instruction* instruction){
   instruction->regtoWrite=&registers[instruction->rt];
   instruction->ALUout=(instruction->immediate) & 0x0000FFFF;
}

/*-------------------------------------------------------------*/
void sb(unsigned int registers[32], Instruction* instruction){
   
   instruction->ALUout = (registers[instruction->rs] + instruction->sign_ext_imm)/4;
   instruction->memData = registers[instruction->rt];
}
void sh(unsigned int registers[32], Instruction* instruction){
   
    instruction->ALUout = (registers[instruction->rs] + instruction->sign_ext_imm)/4;
    instruction->memData = registers[instruction->rt];
}
/* This function takes in an array of registers(unsigned ints) a pointer to an instruction struct, the memory array. 
 * This function sets the rt register and stores it in M[rs + sign extend imm field]
 * This function has a return type of void.
 */
void sw(unsigned int registers[32], Instruction* instruction){
      instruction->ALUout = (registers[instruction->rs] + instruction->sign_ext_imm)/4;
      instruction->memData = registers[instruction->rt];
}
void syscall(unsigned int registers[32], Instruction* instruction, MultiCycleState* ms){

      if(registers[2]==10){
      haltflag = 1;
      //printRegisters(registers, ms);

   }
}





















void runRType(unsigned int registers[32], Instruction* instruction, MultiCycleState* ms){
   /*NOTE: I am assuming the rd register gets set if needed(ie. not a jump) each function*/
   if( (!(instruction->code==0x08||instruction->code==0x09||instruction->code==0x0C)))
   {
      if ( instruction->is_valid)
      {
         ms->wbs++;
      }
   }
   if(instruction->code==0x20)
      add(registers, instruction);
   if(instruction->code==0x21)
      addu(registers, instruction);
   if(instruction->code==0x22)
      sub(registers, instruction);
   if(instruction->code==0x23)
      subu(registers, instruction);
   if(instruction->code==0x24)
      executeAnd(registers, instruction);
   if(instruction->code==0x27)
      nor(registers, instruction);
   if(instruction->code==0x25)
      executeOr(registers, instruction);
   if(instruction->code==0x26)
      executeXor(registers, instruction);
   if(instruction->code==0x00)
      sll(registers, instruction);
   if(instruction->code==0x02)
      srl(registers, instruction);
   if(instruction->code==0x03)
      sra(registers, instruction);
   if(instruction->code==0x04)
      sllv(registers, instruction);
   if(instruction->code==0x06)
      srlv(registers, instruction);
   if(instruction->code==0x07)
      srav(registers, instruction);
   if(instruction->code==0x2A)
      slt(registers, instruction);
   if(instruction->code==0x2B)
      sltu(registers, instruction);
   /*NOTE: the jal and jr don't set rd as they only change the program counter*/
   if(instruction->code==0x08)
      jr(registers, instruction);
   if(instruction->code==0x09)
      jalr(registers, instruction);
   if(instruction->code==0x0C&&registers[2]==10)
      syscall(registers, instruction, ms);
}
void runIType(unsigned int registers[32], Instruction* instruction,  MultiCycleState* ms){
   if(!(instruction->code==0x04||instruction->code==0x05)){
    
   ms->wbs++;
   }
   if(instruction->code==0x08)
      addi(registers, instruction);
   if(instruction->code==0x09)
      addiu(registers, instruction);
   if(instruction->code==0x0C)
      andi(registers, instruction);
   if(instruction->code==0x0D)
      ori(registers, instruction);
   if(instruction->code==0x0E)
      xori(registers, instruction);
   if(instruction->code==0x0A)
      slti(registers, instruction);
   if(instruction->code==0x0B)
      sltiu(registers, instruction);
   if(instruction->code==0x04)
      beq(registers, instruction);
   if(instruction->code==0x05)
      bne(registers, instruction);
   if(instruction->code==0x20)
      lb(registers, instruction);
   if(instruction->code==0x24)
      lbu(registers, instruction);
   if(instruction->code==0x21)
      lh(registers, instruction);
   if(instruction->code==0x25)
      lhu(registers, instruction);
   if(instruction->code==0x0F)
      lui(registers, instruction);
   if(instruction->code==0x23)
      lw(registers, instruction);
   if(instruction->code==0x28)
      sb(registers, instruction);
   if(instruction->code==0x29)
      sh(registers, instruction);
   if(instruction->code==0x2B)
      sw(registers, instruction);
}
void runJType(unsigned int registers[32], Instruction* instruction, MultiCycleState* ms){
   if(instruction->code==0x02)
      j(registers, instruction);
   if(instruction->code==0x03)
      jal(registers, instruction);
}
void printRegisters(unsigned int registers[32], MultiCycleState* ms){
  int i;
  printf("Registers: ");
  for(i=0;i<32;i++){
    printf("0x%08X ", registers[i]);
  }
  printf("\n\n");
  printf("\nPipeline Clocks: %d", ms->total_clocks);
  printf("\nIFs: %d, IDs: %d, EXs: %d, Mems: %d, WBs: %d\n", ms->ifs, ms->ids, ms->insts_run, ms->mem_references, ms->wbs);
}
/*this function increments the clock cycles for a R type instruction*/
void incrementRTypeClocks(unsigned int registers[32], Instruction* instruction, MultiCycleState* ms){
   assert(instruction->is_valid==TRUE);
   unsigned int rs_val= registers[instruction->rs];
   unsigned int inst_clocks=0;
   /*the instruction is a jr or jalr*/
   if(instruction->code==0x09||instruction->code==0x08){
      ms->clock_cycles+=2;
      return;
   }
   /*the instruction is a shift*/
   if(instruction->code==0x00||instruction->code==0x02||instruction->code==0x03||instruction->code==0x04||
      instruction->code==0x06||instruction->code==0x07){
      inst_clocks= 3+rs_val;
      ms->clock_cycles+=inst_clocks;
      return;
   }
   else
      ms->clock_cycles+=4;
}
/*this function increments the clock cycles for a j type instruction*/
void incrementITypeClocks(Instruction* instruction, MultiCycleState* ms){
   assert(instruction->is_valid==TRUE);
   /*the instruction is a branch*/
   if(instruction->code==0x04||instruction->code==0x05){
      ms->clock_cycles+=3;
      return;
   }
   /*the instruction is a load other than an lui*/
   if(instruction->code==0x20||instruction->code==0x24||instruction->code==0x21||instruction->code==0x25||
      instruction->code==0x23){
      ms->clock_cycles+=5;
   return;
   }
   else
      ms->clock_cycles+=4;
}
