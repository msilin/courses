#define ASSOCIATIVITY 4/*used to set the associativity field in the cache struct*/
#define MAX_SIZE 256 /*size of cache(ie. the number of blocks)*/
#define FALSE 0
#define TRUE 1



void mem_write(int *mp);

typedef struct{
   int valid;
   long int index;
   long int tag;
   long int offset;
}Block;

typedef struct{
   Block blocks[MAX_SIZE][ASSOCIATIVITY];
}Cache;
typedef struct{
   int hits;
   int misses;
}State;
void initCache(Cache* c);
double getOffsetSize(int* mp);
long int getOffset(int* mp,double offset_size);
void matmul(int r1, int c1, int c2, Cache* c, State* s);
void mem_read(int *mp, Cache* c, State* s);
long int getIndex(int* mp, double offset_size, double* index_size);
long int getTag(int* mp, double offset_size, double* index_size);
Cache findBlock(Cache* c, State* s, long int index, long int tag, long int offset);