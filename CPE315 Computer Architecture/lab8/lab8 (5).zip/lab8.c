


#define AMAX 10     /* Maximum (square) array size */

#define CACHESIM 1  /* Set to 1 if simulating Cache */
#define SEED 1001 /*random seed for replacing stuff*/

#include <stdio.h>
#include "lab8.h"
#include "assert.h"
#include "math.h"
#include <stdlib.h>



/* Statically define the arrays a, b, and mult, where mult will become the cross product of a and b, i.e., a x b. */

static int a[AMAX][AMAX], b[AMAX][AMAX], mult[AMAX][AMAX];




int main()
    {
    int r1, c1, r2, c2, i, j, k;

    int *mp1, *mp2, *mp3;
    Cache c;
    State s;
    s.hits=0;
    s.misses=0;
    srand(SEED);
    printf("Size of pointer is: %lu\n\n", sizeof(mp1));

    printf("Enter rows and column for first matrix: ");
    scanf("%d%d", &r1, &c1);
    printf("Enter rows and column for second matrix: ");
    scanf("%d%d",&r2, &c2);
    initCache(&c);
/* If column of first matrix in not equal to row of second matrix, asking user to enter the size of matrix again. */
    while (c1 != r2)
        {
        printf("Error! column of first matrix not equal to row of second.\n");
        printf("Enter rows and column for first matrix: ");
        scanf("%d%d", &r1, &c1);
        printf("Enter rows and column for second matrix: ");
        scanf("%d%d",&r2, &c2);
        }

/* Storing elements of first matrix. */

    printf("\nEnter elements of matrix 1:\n");
    for(i=0; i<r1; ++i)
    for(j=0; j<c1; ++j)
          {
//        printf("Enter elements a%d%d: ",i+1,j+1);
//        scanf("%d",&a[i][j]);
  a[i][j] = i+j; // build sample data

          }

/* Storing elements of second matrix. */
    printf("\nEnter elements of matrix 2:\n");
    for(i=0; i<r2; ++i)
    for(j=0; j<c2; ++j)
    {
//        printf("Enter elements b%d%d: ",i+1,j+1);
//        scanf("%d",&b[i][j]);

         b[i][j] = 10 + i + j;
    }


   matmul(r1, c1, c2, &c, &s);    /* Invoke matrix multiply function */ 
    printf("HITS %d, MISSES: %d\n",s.hits, s.misses);

/* Displaying the multiplication of two matrix. */
    printf("\nOutput Matrix:\n");
    for(i=0; i<r1; ++i)
    for(j=0; j<c2; ++j)
    {
        printf("%d  ",mult[i][j]);
        if(j==c2-1)
            printf("\n\n");
    }
    return 0;
}


/*  memory management, code density, Cache emulation - statistics generation */
/*  Generated for CSC 315 Lab 5 */


/* This function gets called with each "read" reference to memory */

void mem_read(int *mp, Cache* c, State* s)
  {
    double index_size;
    double offset_size= getOffsetSize(mp);
    long int offset= getOffset(mp, offset_size);
    long int index= getIndex(mp, offset_size, &index_size);
    long int tag= getTag(mp, offset_size, &index_size);
    *c= findBlock(c, s, index, tag, offset);
    
  /* printf("Memory read from location %p\n", mp);  */

  }


/* This function gets called with each "write" reference to memory */

void mem_write(int *mp)
  {
    double index_size;
    double offset_size= getOffsetSize(mp);
    long int offset= getOffset(mp, offset_size);
    long int index= getIndex(mp, offset_size, &index_size);
    long int tag= getTag(mp, offset_size, &index_size);
    *c= findBlock(c, s, index, tag, offset);

  }




void matmul(int r1, int c1, int c2, Cache* c, State* s)
   {
   int i,j,k;
   int *mp1, *mp2, *mp3;



/* Initializing elements of matrix mult to 0.*/
    for(i=0; i<r1; ++i)
     for(j=0; j<c2; ++j)
       {
       mult[i][j]=0;
       }

/* Multiplying matrix a and b and storing in array mult. */

    for(i=0; i<r1; ++i)
     for(j=0; j<c2; ++j)
      for(k=0; k<c1; ++k)
        {

#if CACHESIM    /* "Hooks" to measure memory references - enabled if CACHESIM  */

        mp1 = &mult[i][j];
  mp2 = &a[i][k];
  mp3 = &b[k][j];   
  mem_read(mp1, c,s);
  mem_read(mp2, c,s);
  mem_read(mp3, c,s);
  mem_write(mp1); 
#endif

        mult[i][j]+=a[i][k]*b[k][j];

        }
   }
void initCache(Cache* c){
  int i;
  int j;
  for(i=0;i<MAX_SIZE;i++){
    for(j=0;j<ASSOCIATIVITY;j++){
      c->blocks[i][j].valid= FALSE;
    }
  }
}
/*calculates the size of the offset field*/
double getOffsetSize(int* mp){
  unsigned int machine_size= sizeof(mp);
  double offset_size= log2((double)machine_size);
  return offset_size;
}
/*gets the offset's value*/
long int getOffset(int* mp, double offset_size){
  long int offset;
  /*the machine size is 32 bits*/
  if(offset_size==2.0){
    assert(sizeof(mp)==4);
    offset= (long int)mp & 0x03;
  }
  /*the size of the machine is 64 bits*/
  else{
    assert(sizeof(mp)==8.0);
    offset= (long int)mp & 0x07;
  }
  return offset;
}
long int getIndex(int* mp, double offset_size, double* index_size){
  long int index;
  long int mem= (long int)mp >> (int)offset_size;
  *index_size= log2((double)MAX_SIZE);
  if(*index_size==4.0){
    index= mem & 0x0F;
  }
  else{
    assert(*index_size==8.0);
    index= mem & 0x0FF;
  }
  return index;
}
long int getTag(int* mp, double offset_size, double* index_size){
  long int offset_and_index_size= (long int)offset_size+(long int)index_size;
  long int tag= tag>>offset_and_index_size;
  return tag;
}
/*adds the entry to cache if need be, otherwise, finds the entry in the cache 
 * otherwise increments hits*/
Cache findBlock(Cache* c, State* s, long int index, long int tag, long int offset){
  int blockNum;
  int Anum;
  int removed_i;
  for(blockNum=0; blockNum<MAX_SIZE; blockNum++){
    for(Anum=0;Anum<ASSOCIATIVITY;Anum++){
      if(c->blocks[blockNum][0].valid==FALSE){
        c->blocks[blockNum][Anum].valid= TRUE;
        c->blocks[blockNum][Anum].index= index;
        c->blocks[blockNum][Anum].tag= tag;
        c->blocks[blockNum][Anum].offset= offset;
        s->misses +=1;
        return *c;
      }
      if(c->blocks[blockNum][Anum].valid==TRUE){
        if(c->blocks[blockNum][Anum].tag==tag&&c->blocks[blockNum][Anum].index==index){
          s->hits+=1;
          return *c;
        }
        if(Anum==ASSOCIATIVITY-1&&c->blocks[blockNum][Anum].index==index){
          removed_i= rand()%ASSOCIATIVITY;
          c->blocks[blockNum][Anum].tag= tag;
          s->misses +=1;
          return *c;
        }
      }
      /*if there's an empty associativity spot to place the block*/
      if(c->blocks[blockNum][Anum].valid==FALSE&&blockNum>0&&c->blocks[blockNum][Anum-1].index==index){
        c->blocks[blockNum][Anum].valid= TRUE;
        c->blocks[blockNum][Anum].index= index;
        c->blocks[blockNum][Anum].tag= tag;
        c->blocks[blockNum][Anum].offset= offset;
        s->misses +=1;
        return *c;
      }
    }
  }
  removed_i= rand()%MAX_SIZE;
  /*clear a whole block section*/
  for(Anum=0; Anum<ASSOCIATIVITY;Anum++){
    c->blocks[removed_i][Anum].valid= FALSE;
  }
  c->blocks[removed_i][0].index= index;
    c->blocks[removed_i][0].tag= tag;
    c->blocks[removed_i][0].offset= offset;
    c->blocks[removed_i][0].valid= TRUE;
    s->misses +=1;
    return *c;
}