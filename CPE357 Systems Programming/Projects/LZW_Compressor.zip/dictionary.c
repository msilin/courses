#include "bitPacker.h"
#include "dictionary.h"

void buildDictionary(int limit, FILE* input, FILE* output)
{
   Bitpacker bp;
   TrieNode* dictionary;
   int ch;
   initializeDictionary(&dictionary, &bp, &ch, input); 
   fwrite(&limit, 1, sizeof(char), output); 
   while( (ch = fgetc(input))!=EOF)
   { 
      if ( bp.count == 1<<(bp.r))
         increaseSize(&dictionary, &bp);
      if (dictionary[bp.code].array[ch] == 0 )
      {
         dictionary[bp.code].array[ch] = ++bp.count;
         packbits(&bp, &(bp.code), output);
         bp.code = ch;
      }
      else 
         bp.code = dictionary[bp.code].array[ch];
      if ( bp.count == 1<<limit)
         recycle(&dictionary, &bp, ch);  
      
   }

   packEOD(&bp, output, &dictionary);
   free(dictionary);
}
void initializeDictionary(TrieNode** dictionary, Bitpacker *bp, 
   int *ch, FILE* input)
{
   *ch = fgetc(input);
   if(*ch==EOF)
      exit(EXIT_SUCCESS);
   bp->bits = 0;
   bp->remainder =0;
   bp->r = 9;
   bp->size=1;
   bp->count = 256;
   *dictionary = calloc(512, sizeof(TrieNode));
   if(!*dictionary)
   {
      perror("");
      exit(EXIT_FAILURE);
   }
   bp->code = *ch;
}
void increaseSize(TrieNode** dictionary, Bitpacker * bp)
{
   int i;
   if(bp->size)
   {
      *dictionary = realloc(*dictionary, sizeof(TrieNode)*(1<<(bp->r+1)));
      if(!*dictionary)
      {
         perror("");
         exit(EXIT_FAILURE);
      }
   }
   for (i=(1<<bp->r);i<(1<<(bp->r+1));i++)
      memset( ((*dictionary)[i].array) ,0, sizeof(short)*256);

   bp->r++;
}
void packEOD(Bitpacker* bp, FILE* output, TrieNode ** dictionary)
{
   int EOD;
   EOD = 256;
   if ( bp->count++ == 1<<(bp->r))
      bp->r++; 
   packbits(bp, &bp->code, output);
   if ( bp->count == 1<<(bp->r))
      bp->r++; 
   packbits(bp, &EOD, output);
   EOD = 0;
   if (bp->bits )
      fwrite(&EOD, 1, 1, output);
}

void recycle(TrieNode** dictionary, Bitpacker* bp, unsigned char ch)
{
   int i =0;
   bp->code = ch;
   bp->r = 9;
   memset(*dictionary, 0, sizeof(TrieNode) * bp->count);
   while ( i < 256)
   {
      memset( ((*dictionary)[i].array) ,0, sizeof(short)*256);
      i++;
   }
   bp->size=0;
   bp->count = 256;
}