#ifndef DICTIONARY_H
#define DICTIONARY_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define NUMBER_OF_SYMBOLS 256

typedef struct trieNode
{
   short array[NUMBER_OF_SYMBOLS];
} TrieNode;

void buildDictionary(int limit, FILE* input, FILE* output);
void initializeDictionary(TrieNode** dictionary, Bitpacker * bp, int *ch, FILE* input);
void increaseSize(TrieNode** dictionary, Bitpacker * bp);
void packEOD(Bitpacker* bp, FILE* output, TrieNode** dictionary);
void recycle(TrieNode** dictionary, Bitpacker* bp, unsigned char ch);


#endif