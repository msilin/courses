#include "bitPacker.h"

void packbits(Bitpacker* bp, int *ch, FILE* output)
{
   int mask;
   bp->bits += bp->r-8; 
   mask = (1<<(bp->bits))-1; /* create mask */  
   *ch |= (bp->remainder << bp->r);
   bp->remainder = (*ch & mask); /*new remainder*/
   *ch >>= bp->bits;
   fwrite(ch, 1, sizeof(char), output);
   if (bp->bits>7)
      writeRemainder(bp, output);
}

void writeRemainder(Bitpacker* bp, FILE* output)
{
   int code, mask;

   bp->bits -=8;
   code = (bp->remainder)>>(bp->bits);  
   fwrite(&code, 1, sizeof(char), output);
   mask = (1<<((bp->bits)))-1;
   bp->remainder = (bp->remainder & mask);

}