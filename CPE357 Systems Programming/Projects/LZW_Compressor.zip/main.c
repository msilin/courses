#include <string.h>
#include "bitPacker.h"
#include "dictionary.h"

#define NUMBER_OF_SYMBOLS 256

FILE* openFile(char **file, char* args);
void checkArgs(int argc, char **argv, int *r, char** file);
void showUsage();

int main(int argc, char **argv)
{
   FILE *input, *output;
   char* file;
   int limit = 0;

   checkArgs(argc,argv, &limit, &file);
   input = openFile(&file, "r");
   strcat(file, ".lzw");
   output = openFile(&file, "w+");

   buildDictionary(limit, input, output);
   fclose(input);
   fclose(output);
   exit(EXIT_SUCCESS);
}
   
FILE* openFile(char **file, char* args)
{
   FILE* fp;
   if (! (fp=fopen(*file, args)) )
   {
      fprintf(stderr, "lzwCompress: %s: ", *file);
      perror("");
      exit(EXIT_FAILURE);
   }
   return fp;
}

void checkArgs(int argc, char **argv, int *limit, char** file)
{
   *file = argv[1];
   if ( argc == 2)
      *limit = 12;
   else if (argc == 3)
   {
      if (!memcmp(argv[1], "-r", 2) && (*argv[2] != '-'))
      {
         sscanf(argv[1]+2, "%d", limit);
         *file = argv[2];
      }
      else if (!memcmp(argv[2], "-r", 2) && (*argv[1] != '-'))
         sscanf(argv[2]+2, "%d", limit);
   }
   if ((*limit<9) || (*limit>15))
      showUsage();
}

void showUsage()
{
   fprintf(stderr, "Usage: lzwCompress [-rN] file\n");
   fprintf(stderr, "Where: N is a number from 9 to 15 specifying"
      " the recycle code as a power of 2\n");
   exit(EXIT_FAILURE);
}
