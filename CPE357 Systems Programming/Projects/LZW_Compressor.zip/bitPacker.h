#ifndef BITPACKER_H
#define BITPACKER_H

#include <stdio.h>
#include <stdlib.h>

typedef struct
{
   unsigned short remainder, bits, r, size;
   int code, count;
} Bitpacker;

void packbits(Bitpacker* bp, int *ch, FILE* output);
void writeRemainder(Bitpacker* bp, FILE* output);
#endif

