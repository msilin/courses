#ifndef GETWORD_H
#define GETWORD_H
#include <stdio.h>
#include <stdint.h> /* Replace with <stdint.h> if appropriate */

/* Handy "new" type definition for this function */
typedef unsigned char Byte;
void checkMalloc(void* mem);

unsigned hashWord(const void *data);
void destroyWord(const void *data);
/* Prototype of the function you must write */
int getWord(FILE *file, Byte **word, unsigned *wordLength, int *hasPrintable);
typedef struct
{
   Byte *bytes;
   unsigned length;
} Word;
#endif
