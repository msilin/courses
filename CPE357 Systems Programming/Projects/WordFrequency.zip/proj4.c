#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "getWord.h"
#include "hashTable.h"
#include "hash.h"

#include "UI.h"

void parseFile(HT* ht, FILE* fp);

void destroyWord(const void *data)
{
   const Word *w = data;
   free(w->bytes);
}
int main(int argc, char *argv[])
{
   HT * ht = NULL;
   unsigned size, flag, std_in;
   int i;
   FILE* fp;
   HTEntry *HTArray;
   ht = initializeHT(ht);
   size = i = std_in = 1;
   
   flag = checkFlags(argc, argv, &std_in);
   while ( argc-->1 ||std_in)
   {
      if ( argv[argc][0] != '-' )
      {
         fp = fileOpen(argv[argc], &std_in);
         parseFile(ht, fp);
         fclose(fp);         
      }
   }
   HTArray = htToArray(ht, &size);
   qsortHTEntries(HTArray, size, flag);
   if ( flag == 0)
      flag = 10;
   printArray(size, HTArray, flag, ht);
   free(HTArray);   
   htDestroy(ht, 1);
   
   return 0;
}

HT* initializeHT(HT* ht)
{
   unsigned sizes[] = { 467, 1009, 4001,50551,752569 };
   HTFunctions functions = {hashWord, fastwordcmp, destroyWord};
   ht = htCreate(&functions, sizes, 5, .8);
   return ht;
}
