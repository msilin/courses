#include <stdio.h>
#include <stdlib.h>
#include "getWord.h"
#include <ctype.h>
#include "hash.h"

#define PRIME 0x01000193  /*   16777619*/
#define SEED 0x811C9DC5 /* 2166136261*/
unsigned hashWord(const void *data)  
{/* FNV Hash http://create.stephan-brumme.com/fnv-hash/ */
   unsigned hash = SEED;
   unsigned numBytes = ((Word*)data)->length;
   const unsigned char* ptr = (const unsigned char*)((Word*)data)->bytes;
   while (numBytes--)
      hash = (*ptr++ ^ hash) * PRIME;
   return hash;
}
void checkMalloc(void* mem)
{
   if (!mem)
   {
      perror("wf: ");
      exit(EXIT_FAILURE);
   }
}
int getWord(FILE *file, Byte **word, unsigned *wordLength, int *hasPrintable)
{
   unsigned c, i, mem;
   i = *hasPrintable = 0;
   mem = 4;
   *word = malloc(sizeof(Byte)*mem);
   checkMalloc(*word);
   while (((c = fgetc(file)) != EOF) && isspace(c) );
   while (  (c != EOF) && !isspace(c))
   {
      if (i+1 > mem)
      {
         *word = realloc(*word, (mem*=2)*sizeof(Byte));
         checkMalloc(*word);
      }
      if (( 65 <=  c ) && ( c <= 90 )) 
         c+=32;
      (*word)[i]=c;
      i++;
      if (isprint(c))
         *hasPrintable = 1;            
      c = fgetc(file);
   }
   *wordLength = i;
   *word = realloc(*word, i*sizeof(Byte));
   if ( c != EOF )
      return 0;
   return c;
}
void parseFile(HT* ht, FILE* fp)
{
   Word* word;
   Byte* bytes = NULL;
   unsigned length = 0;
   int hasPrint;
   unsigned c;
   hasPrint = c = 0;
   do
   {
      c = getWord(fp, &bytes, &length, &hasPrint);            
      if (hasPrint != 0)
      {
         word = malloc(sizeof(Word));
         checkMalloc(word);
         word->bytes = bytes;
         word->length = length;
         htAdd(ht,word);
      }
      else 
         free(bytes);
   } while(EOF != c);
}
