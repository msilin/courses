#ifndef UI_H
#define UI_h

void parseFile(HT* ht, FILE* fp);
unsigned checkFlags(int argc, char **argv, unsigned * std_in);
FILE* fileOpen(const char *fname, unsigned * std_in);
void printArray(int size, HTEntry* HTArray, int numlines, HT* ht);
void printWord(const Byte *word, unsigned wordLength, int hasPrintable);


#endif 
