#ifndef HASH_H
#define HASH_H
#include "hashTable.h"
#define min(a,b) ((a) < (b) ? (a) : (b))
#define max(a,b) ((a) > (b) ? (a) : (b))

typedef struct node
{
   HTEntry htEntry;
   struct node *next;
} ListNode;

typedef struct
{
   ListNode **array;
   HTFunctions functions;
   unsigned *sizes;
   unsigned numSizes, capacity, total;
   unsigned unique, size_index;
   float rehashLoadFactor, rehash;
} HT;

void qsortHTEntries(HTEntry *entries, int numberOfEntries, int flag);

void htRehash(void *hashTable);
void assertHT(unsigned* sizes, int numSizes, float rehashLoadFactor);
HT* initializeHT(HT * ht);
void htDestroyHT(void *hashTable);
int fastwordcmp( const void* ht1, const void* ht2);
int slowwordcmp( const void* ht1, const void* ht2);
int htcmpfreq( const void* data1, const void* data2);
#endif
