#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "hashTable.h"
#include "getWord.h"

#define MIN(A,B) ((A) < (B) ? (A) : (B))
#define MAX(A,B) ((A) > (B) ? (A) : (B))

int fastwordcmp( const Word* data1, const Word* data2)
{
   unsigned  min;
   min = MIN(data1->length,data2->length);
   if ( memcmp(data1->bytes,data2->bytes, min) != 0)
   {
      return 1;
   }
   return (data1->length - data2->length);
}
int slowwordcmp( const Word* data1, const Word* data2)
{
   unsigned min;
   min = MIN(data1->length,data2->length);
   if ( memcmp(data1->bytes,data2->bytes, min) == 0)
   {
      return data1->length - data2->length;
   }
   return memcmp(data1->bytes,data2->bytes, min);
}

int htcmpfreq( const void* data1, const void* data2)
{
   return  ((HTEntry*)data2)->frequency - ((HTEntry*)data1)->frequency;
}
int htcmp( const void* data1, const void* data2)
{
   int freq =  ((HTEntry*)data2)->frequency - ((HTEntry*)data1)->frequency;
   if (freq)
      return freq;
   return slowwordcmp( ((HTEntry*)data1)->data, ((HTEntry*)data2)->data);
}
void qsortHTEntries(HTEntry *entries, int numberOfEntries, int flag)
{
   qsort((void*)entries, numberOfEntries, sizeof(HTEntry), htcmp);
}

