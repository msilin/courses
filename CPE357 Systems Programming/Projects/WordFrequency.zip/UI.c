#include <stdlib.h>
#include <stdio.h>
#include <ctype.h>
#include <string.h>
#include "hash.h" 
#include "getWord.h"
#include "UI.h"

void printArray(int size, HTEntry* HTArray, int numlines, HT* ht)
{
   int i = 0;
   size = min(size,numlines);
   printf("%d unique words found in %d total words\n", htUniqueEntries(ht)
      ,htTotalEntries(ht));
   for ( ;i < size; i++)
   {
      printf("%10u - ", HTArray[i].frequency);
      printWord(((Word*)HTArray[i].data)->bytes, ((Word*)HTArray[i].data)
         ->length, 0) ;
   }
}
unsigned checkFlags(int argc, char **argv, unsigned * std_in)
{
   int i = 0;
   *std_in = 1;
   argv++;
   while (argc-- > 1)
   {
      if (!memcmp(*argv,"-n", 2))
      {
         sscanf(*argv+2, "%d", &i);
         if (i == 0 || i < 0)
         {
            fprintf(stderr, "Usage: wf [-nX] [file...]\n");
            exit(EXIT_FAILURE);
         }

      }   
      else if (*argv[0]=='-')
      {
         fprintf(stderr, "Usage: wf [-nX] [file...]\n");
         exit(EXIT_FAILURE);
      }
      else
      {  
         *std_in = 0;
      }
      argv++;
   }
   return i;
}

FILE* fileOpen(const char *fname, unsigned *std_in)
{
   FILE * fp;
   if ( *std_in == 1 )
   {
      fp = stdin;
      *std_in = 0;
   }
   else
      fp = fopen(fname, "r");
   if (fp == NULL)
   {  
      fprintf(stderr, "wf: ");
      perror(fname);
      exit(EXIT_FAILURE);
   }
   return fp;
}

void printWord(const Byte *word, unsigned wordLength, int hasPrintable)
{
   int i = 0;
   /* For readability, this program limits each line to 30 characters max */
   for (i = 0; i < wordLength && i < 30; i++)
   {
      if (isprint(word[i]))
         printf("%c", word[i]);
      else
         printf("%c", '.');
   }
   /* Indicate the word is longer that was actually displayed */
   if (wordLength > 30)
      printf("...");

   printf("\n");
}
