#include <stdlib.h>
#include "hashTable.h"
#include "hash.h"
#include "string.h"
#include "assert.h"
#include "float.h"
#include "limits.h"
#include "getWord.h"

void* htCreate( HTFunctions *functions, unsigned sizes[], int numSizes, 
   float rehashLoadFactor)
{
   HT *ht = malloc(sizeof(HT));
   checkMalloc(ht);
   assertHT(sizes, numSizes, rehashLoadFactor);
   ht->functions = *functions;
   ht->sizes = malloc(sizeof(int)*numSizes);
   checkMalloc(sizes);
   memcpy(ht->sizes, sizes, sizeof(int)*numSizes);
   ht->numSizes = numSizes;
   ht->rehashLoadFactor = rehashLoadFactor;
   ht->unique = ht->total = ht->size_index = 0;
   ht->array = calloc((ht->capacity = ht->sizes[0]), sizeof(ListNode*));
   checkMalloc(ht->array);
   ht->rehash = ht->rehashLoadFactor * ht->capacity;
   if ((ht->numSizes == 1) || ( rehashLoadFactor == 1.0))
      ht->rehash = FLT_MAX;
   return ht;
}

void assertHT(unsigned* sizes, int numSizes, float rehashLoadFactor)
{
   int i = 0;
   assert(numSizes > 0);
   assert(sizes[0] > 0);
   for (i = 1; i < numSizes; i++)
      assert (sizes[i-1] < sizes[i] );
   assert((rehashLoadFactor > 0.0) && (rehashLoadFactor <= 1.0));   
}
void htDestroy(void *hashTable, int destroyData)
{
   HT * ht = hashTable;
   ListNode** array = ht->array;
   ListNode* delete;
   int i;
   for (i = 0; i < ht->capacity; i++)
   {
      while ( array[i] )
      {
         delete = array[i];
         array[i] = array[i]->next;
         if (destroyData)
         {
            if (ht->functions.destroy)
               ht->functions.destroy(delete->htEntry.data);         
            free(delete->htEntry.data);
         }
         free(delete);
      }         
   }
   free(array);
   free(ht->sizes);
   free(ht);
}

unsigned htAdd(void *hashTable, void *data)
{
   int i;
   ListNode* temp;
   HT * ht = hashTable;
   assert(data != ((void *)0));
   ht->total++;
   if ( ht->rehash <= ht->unique )
      htRehash(hashTable);
   i = ht->functions.hash(data) % ht->capacity;
   
   temp = ht->array[ht->functions.hash(data) % ht->capacity];
   while (temp)
   {
      if ( !ht->functions.compare(temp->htEntry.data, data) )
      { 
         ht->functions.destroy(data);
         free(data);
         return ++temp->htEntry.frequency;
      }
      temp = temp->next;
   }
   ht->unique++;
   temp = malloc(sizeof(ListNode));
   checkMalloc(temp);
   temp->htEntry.data = data;
   temp->next = ht->array[i];
   ht->array[i] = temp;   
   return  (temp->htEntry.frequency=1);
}

void htRehash(void *hashTable)
{
   int i, cap, index;
   ListNode ** array;
   ListNode * temp2, *temp;
   HT * ht = hashTable;
   array = ht->array;
   
   ht->size_index++;

   ht->array = calloc(ht->sizes[ht->size_index], sizeof(ListNode*));
   for (i = 0; i < ht->capacity; i++)
   {
      temp = array[i];
      cap = ht->sizes[ht->size_index];
      while (temp)
      {
         temp2 = temp->next;
         index = ht->functions.hash(temp->htEntry.data) % cap;
         temp->next = ht->array[index];
         ht->array[index] = temp;
         temp = temp2;     
      }
   }
   ht->capacity = cap;
   
   ( ht->size_index == ht->numSizes - 1) ? (ht->rehash = FLT_MAX) : 
      (ht->rehash = ht->rehashLoadFactor * ht->capacity);
 
   free(array);
}

HTEntry htLookUp(void *hashTable, void *data)
{
   HTEntry ht_entry;
   int i;
   ListNode* temp;
   HT * ht = hashTable; 
   assert( data!=NULL );
   i =  ht->functions.hash(data) % ht->capacity;

   temp =  ht->array[i];
   while ( temp )
   {
      if (!ht->functions.compare(data, temp->htEntry.data) )
      {
         ht_entry = temp->htEntry;
         return ht_entry;
      }
      temp = temp->next;
   }
   ht_entry.frequency = 0;
   ht_entry.data = NULL;
   return ht_entry;
}

HTEntry* htToArray(void *hashTable, unsigned *size)
{
   int i, j;
   HT * ht = hashTable;
   HTEntry * ht_entry_ptr = NULL;
   ListNode* temp;
   if ( !ht->unique)
   {
      *size = 0;
      return ht_entry_ptr;
   }
   ht_entry_ptr = malloc( ht->unique * sizeof(HTEntry) );
   i = j = 0;
   for (; i < ht->capacity; i++) 
   {
      temp = ht->array[i];      
      while (temp)
      {
         ht_entry_ptr[j] = temp->htEntry;
         temp = temp->next;
         j++;
      }
   }
   *size = j;
   return ht_entry_ptr;
}

unsigned htCapacity(void *hashTable)
{
   return ((HT*)hashTable)->capacity;
}

unsigned htUniqueEntries(void *hashTable)
{
   return ((HT*)hashTable)->unique;
}

unsigned htTotalEntries(void *hashTable)
{
   return ((HT*)hashTable)->total;
}

HTMetrics htMetrics(void *hashTable)
{
   HTMetrics metrics;
   HT * ht = hashTable;
   ListNode* temp;
   int i, max, size;
   max = size = i = metrics.numberOfChains = 0;
   for (; i < ht->capacity ; i++)
   {
      temp = ht->array[i];
      if (temp)
         metrics.numberOfChains++;
      while ( temp )
      {         
         temp = temp->next;
         size++;
      }
      if (size > max)
         max = size;
      size = 0;        
   }
   (metrics.numberOfChains) ? (metrics.avgChainLength = ht->unique / 
      (float)metrics.numberOfChains) : (metrics.avgChainLength = 0);
   metrics.maxChainLength = max;   
   return metrics;
}
ListNode* addHead(ListNode *oldHead, void* data)
{
   ListNode * newHead = malloc(sizeof(ListNode));
   newHead->htEntry.data = data;
   newHead->next = oldHead;
   newHead->htEntry.frequency = 1;
   return newHead;
}
