#ifndef GAME_H
#define GAME_H

typedef struct{

int seed;
char maxLetter;
int positions;
int maxGuesses;
char answer[10];

} Board;
void setupBoard(Board * board);
void initializeBoard(Board * board);
int checkGuess(char * guessPtr, Board * board);
int playGame(Board * board);
int checkExact(Board * board, char * temp, char * guess);
int checkInexact(Board * board, char * temp, char * guess);
void showBoard(Board * board);
void gameOver(int i);
#endif
