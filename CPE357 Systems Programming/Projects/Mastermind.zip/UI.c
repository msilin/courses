#include <stdio.h>
#include <stdlib.h>
#include "UI.h"
#include "game.h"

void getSeed(Board * board)
{
   while (1)
   {
      printf("Enter the seed for random number generation: ");    
      if ( !scanf("%d", &board->seed))
      {
         printf("Seed must be an integer value, please try again\n");
         clearBuffer();
      }
      else
      {
         break;
      }
   }
}

void getLetter(Board * board)
{
   while (1)
   {
      printf("Enter the maximum letter for the game (A-Z): ");
      scanf(" %c", &board->maxLetter);
      if ( ( 65 > board->maxLetter ) || ( board->maxLetter > 91) )
      {
         printf("The letter must be an uppercase A-Z, please try again\n");
         clearBuffer();
      }
      else
      {
         clearBuffer();
         break;
      }
   }
}

void getPositions(Board * board)
{
   while (1)
   {
      printf("Enter the number of positions for the game (1-8): ");
      scanf("%d", &board->positions);
      clearBuffer();
      if ( ( 1 > board->positions ) || ( board->positions > 8) )
      {
         printf("The number of positions must be 1-8, please try again\n");
      }
      else
      {
         break;
      }
   }
}

void getGuesses(Board * board)
{
   while (1)
   {
      printf("Enter the number of guesses allowed for the game: ");
      scanf("%d", &board->maxGuesses);
      clearBuffer();
      if ( 1 > board->maxGuesses )
      {
         printf("The number of guesses must be a positive integer,"
            " please try again\n");
      }
      else
      {
         break;
      }
   }
}

void getGuess(int i, char * guessPtr, Board * board)
{
   while (1)
   {
      printf("\nEnter guess %d: ", i+1); 
      guessInput(guessPtr, board);
      clearBuffer();
      if (checkGuess(guessPtr, board))
      {
         break;
      }
   }
}
void guessInput(char * guessPtr, Board * board)
{
   int j = 0; 
   for (j = 0; j < board->positions; j++)      
   {
      guessPtr[j] = getchar();
      if ( guessPtr[j] == '\n')
      {
         j--;
      }   
   }
   guessPtr[j] = '\0';
}
void clearBuffer()
{
   char c;
   while(1){
      c = getchar();
      if ( c == '\n')
      {
         break;
      }
      else if ( c == EOF)
      {
         fprintf(stderr, "Unexpected EOF\n");
         exit(1);
      }
   }
}
void gameOver(int i)
{
   if (i)
   {
      printf("\nWow, you won in %d guesses - well done!\n", i);
   }
   else
   {
      printf("\nGame over, you ran out of guesses. Better luck next time!\n");
   }
}