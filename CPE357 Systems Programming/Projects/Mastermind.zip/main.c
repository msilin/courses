#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "UI.h"
#include "game.h"

int main(int argc, char * argv[])
{
   Board board;
   int i = 0;
   
   if (argc > 1)
   {   
      if (!strcmp(argv[1], "-show")&& (argc == 2))
      {
         i = 1;
      }
      else
      {
         fprintf(stderr, "Usage: mastermind [-show]\n");
         exit(EXIT_FAILURE);        
      }
   }
   setupBoard(&board);
   if ( i == 1)
   {
      showBoard(&board);
   }
   gameOver(playGame(&board));
   return 0;
}

