#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "UI.h"
#include "game.h"

void setupBoard(Board * board)
{
   getSeed(board);
   getLetter(board);
   getPositions(board);
   getGuesses(board);
   initializeBoard(board);
}
void initializeBoard(Board * board)
{
   int i, j, k;
   srand((unsigned) board->seed);
   j = board->maxLetter - 64;
   for (i = 0; i < board->positions; i++)
   {
      k = (int)rand() % j;
      board->answer[i] = k + 65;
   }
   board->answer[i] = '\0';   
}
int checkGuess(char * guessPtr, Board * board)
{
   int j;
   for (j = 0; j < board->positions; j++)      
   {
      if ( 65 > guessPtr[j]  || guessPtr[j] > board->maxLetter) 
      {
         printf("Invalid guess, please try again\n");
         return 0;
      }
   }         
   return 1;
}
int playGame(Board * board)
{
   int i, exact, inexact;
   char guess [10];
   char temp [10];    
   for (i = 0; i < board->maxGuesses; i++)
   {  
      exact = inexact = 0;
      strcpy(temp, board->answer);    
      getGuess(i, guess, board);
      if ( strcmp(temp, guess) == 0)
      {
         return i+1;
      }
      exact += checkExact(board, temp, guess);
      inexact += checkInexact(board, temp, guess);
      printf("Nope, %d exact guesses and %d inexact guesses\n", exact, inexact);
   }
   return 0;
}

int checkExact(Board * board, char * temp, char * guess)
{
   int i , j;
   i = 0;
   for (j = 0 ; j < board->positions; j++)
   {
      if ( temp[j] == guess[j] )
      {
         temp[j] = '0';
         guess[j] = '1';
         i++;
      }
   }
   return i;
}

int checkInexact(Board * board, char * temp, char * guess)
{
   int i, j;
   char *tempPtr;
   i = 0;
   for (j = 0 ; j < board->positions; j++)
   {
      tempPtr = strchr(temp,guess[j]);
      if ( tempPtr )
      {
         *tempPtr = '0';
         i++;
      }
   }
   return i;
}
void showBoard(Board * board)
{
   printf("Initialized Game Board: %s\n", board->answer);
}