#ifndef UI_H
#define UI_H
#include "game.h"

void getSeed(Board * board);
void getLetter(Board * board);
void getPositions(Board * board);
void getGuesses(Board * board);
void getGuess(int i, char * guessPtr, Board * board);
void guessInput(char * guessPtr, Board * board);
void clearBuffer();

#endif
