#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>
#include "string.h"
#include "WC.h"
#include "UI.h"

void runWC(int argc, char*argv[], WC *wc)
{
   if (!wc->l && !wc->w && !wc->c)
   {
      wc->l = wc->w = wc->c = 1;
   }   
   if (!wc->foo)
   {
      runCount(wc, NULL);
   }
   for (wc->i = 1;wc->i < argc; wc->i++)
   {
      if (argv[wc->i][0] != '-')
      {
         wc->files++;
         runCount(wc, argv[wc->i]);
      }
   }
}
void runCount(WC* wc, char* ch)
{   
   if ((wc->fp = fileOpen(ch)))
   {
      count(ch, wc);
      tallyMultiFiles(wc);
      wc->lines = wc->words = wc->chars = 0;
   }
   else
   {
      wc->error = 1;
   }
}

void count(char * fileName, WC *wc)
{
   wc->STATE = 0;  
   wc->fileName = fileName;
   while ((wc->ch = fgetc(wc->fp)) != EOF)
   {
      wc->chars++;
      if (wc->ch == '\n')
      {
         wc->lines++;
      }
      if (isspace(wc->ch))
      {
         wc->STATE = 0;  
      }
      else if (!wc->STATE && isprint(wc->ch))
      {
         wc->words++;
         wc->STATE = 1;
      }
   }
   printResults(wc);
}
void tallyMultiFiles(WC *wc)
{
   wc->tl += wc->lines;
   wc->tc += wc->chars;
   wc->tw += wc->words;
}