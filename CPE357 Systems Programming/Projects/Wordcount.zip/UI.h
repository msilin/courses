#ifndef UI_H
#define UI_H

void printResults(WC* wc);
void printMultiFiles(WC *wc);
void checkFlags(WC *wc, char* ch);
FILE* fileOpen(const char *fname);

#endif