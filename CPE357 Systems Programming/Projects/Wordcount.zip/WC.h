#ifndef WC_H
#define WC_H

typedef struct
{
	unsigned int ch, chars, lines, words, word;
	int i, tc, tl, tw, l, w, c, files, STATE;
	int foo, error;
	char * fileName;
	FILE * fp;
}WC;

void count(char* fileName, WC *wc);
void tallyMultiFiles(WC *wc);
void runCount(WC* wc, char* ch);
void runWC(int argc, char*argv[], WC *wc);



#endif