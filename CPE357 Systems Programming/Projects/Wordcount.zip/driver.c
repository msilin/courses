#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>
#include "string.h"
#include "WC.h"
#include "UI.h"

void initializeWC(WC* wc);

int main(int argc, char *argv[])
{
   WC wc;
   initializeWC(&wc);
   for (wc.i = 1;wc.i < argc; wc.i++)
   {
      checkFlags(&wc, argv[wc.i]);
   }   
   runWC(argc, argv, &wc);
   if ( wc.files > 1)
   {
      printMultiFiles(&wc);      
   }
   if (wc.error)
   {
      exit(EXIT_FAILURE);
   }
   return 0;
}

void initializeWC(WC* wc)
{
   wc->l = wc->w = wc->c = wc->tc = wc->tl = wc->tw = wc->files = wc->foo =
      wc->error = 0;
}

