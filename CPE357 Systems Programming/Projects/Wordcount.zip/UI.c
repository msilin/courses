#include <stdio.h>
#include <stdlib.h>
#include "WC.h"
#include "UI.h"
#include "string.h"

void printMultiFiles(WC * wc)
{
   char total[] = "total";
   wc->lines = wc->tl;
   wc->chars = wc->tc;
   wc->words = wc->tw;
   wc->fileName = total;
   printResults(wc);
}

void printResults(WC* wc)
{
   int ch = 0;
   if (wc->l)
   {
      printf("%10u", wc->lines);
      ch = 1;
   }
   if (wc->w)
   {
      if (ch)
      {
         printf(" ");
      }
      printf("%10u", wc->words);
      ch = 1;
   }
   if (wc->c)
   {
      if (ch)
      {
         printf(" ");
      }
      printf("%10u", wc->chars);
   }
   if (wc->fileName)
   {
      printf(" %s", wc->fileName);
   }
   printf("\n");
}
void checkFlags(WC *wc, char* ch)
{
   if (!strcmp(ch,"-l"))
   {
      wc->l = 1;
   }
   else if (!strcmp(ch,"-w"))
   {
      wc->w = 1;
   }
   else if (!strcmp(ch,"-c"))
   {
      wc->c = 1;
   }
   else if (ch[0]=='-')
   {
      fprintf(stderr, "swc: invalid option: '%s'\n", ch);
      fprintf(stderr, "Usage: swc [-l|-w|-c]... [file]...\n");
      exit(EXIT_FAILURE);
   }
   else
   {
      wc->foo = 1;
   }
}
FILE* fileOpen(const char *fname)
{
   FILE * fp;
   if ( fname == NULL)
   {
      fp = stdin;
   }
   else
   {
      fp = fopen(fname, "r");
   } 
   if (fp == NULL)
   {
      fprintf(stderr, "swc: ");
      perror(fname);
   }
   return fp;
}