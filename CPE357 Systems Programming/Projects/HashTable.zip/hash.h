#ifndef HASH_H
#define HASH_H
typedef struct node
{
   HTEntry htEntry;
   struct node *next;
} ListNode;

typedef struct
{
	ListNode **array;
	HTFunctions functions;
	unsigned *sizes;
	int numSizes, capacity, unique, total, chains;
	float rehashLoadFactor, math;
	
	int key, sizeIndex;

} HT;

ListNode* addHead(ListNode *list, void* data);
ListNode* deleteNode(ListNode *list, int index);

void htRehash(void *hashTable);
void assertHT(unsigned* sizes, int numSizes, float rehashLoadFactor);
void initializeHT(HT * ht);
void htDestroyHT(void *hashTable);
void htDestroyNodes(void *hashTable, int destroyData, int i);
void copyToArray(void *hashTable, ListNode* oldNode);


#endif
