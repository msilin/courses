#include <stdlib.h>
#include "hashTable.h"
#include "hash.h"
#include "string.h"
#include "assert.h"
#include "float.h"
#include "limits.h"
ListNode* addHead(ListNode *oldHead, void* data)
{
   ListNode * newHead = malloc(sizeof(ListNode));
   newHead->htEntry.data = data;
   newHead->next = oldHead;
   newHead->htEntry.frequency = 1;
   return newHead;
}

ListNode* deleteHead(ListNode *list, int destroyData)
{
   ListNode * deleteMe = list;
   list = list->next;
   if (destroyData)
   { 
      (free(deleteMe->htEntry.data));
   }
   free(deleteMe);
   return list;
}

void* htCreate( HTFunctions *functions, unsigned sizes[], int numSizes, 
   float rehashLoadFactor)
{

   HT *ht = malloc(sizeof(HT));
   assertHT(sizes, numSizes, rehashLoadFactor);
   ht->functions = *functions;
   ht->sizes = malloc(sizeof(int)*numSizes);
   memcpy(ht->sizes, sizes, sizeof(int)*numSizes);
   ht->numSizes = numSizes;
   ht->rehashLoadFactor = rehashLoadFactor;
   ht->unique = 0;
   ht->total = 0;
   ht->capacity = ht->sizes[0];
   ht->sizeIndex = 0;
   ht->array = calloc(ht->sizes[0], sizeof(ListNode*));
   ht->math = ht->rehashLoadFactor * ht->capacity;
   if ((ht->numSizes == 1) || ( rehashLoadFactor == 1.0))
   {
      ht->math = FLT_MAX;
   }
   return ht;
}

void assertHT(unsigned* sizes, int numSizes, float rehashLoadFactor)
{
   int i = 0;
   assert(numSizes > 0);
   assert(sizes[0] > 0);
   for (i = 1; i < numSizes; i++)
   {  
      assert (sizes[i-1] < sizes[i] );
   }
   assert((rehashLoadFactor > 0.0) && (rehashLoadFactor <= 1.0));   
}
void htDestroy(void *hashTable, int destroyData)
{
   HT * ht = hashTable;
   int i;
   for (i = 0; i < ht->capacity; i++)
   {
      while ( ht->array[i] )
      {
         htDestroyNodes(hashTable, destroyData, i);
      }         
   }
   free(ht->array);
   free(ht->sizes);
   free(ht);
}

void htDestroyNodes(void *hashTable, int destroyData, int i)
{
   HT * ht = hashTable;
   if (ht->functions.destroy && destroyData)
   {
      ht->functions.destroy(ht->array[i]->
         htEntry.data);
   }
   ht->array[i] = deleteHead(ht->array[i],
      destroyData);
}
unsigned htAdd(void *hashTable, void *data)
{
   int i, j, comparedData;
   ListNode* temp;
   HT * ht = hashTable;
   assert(data != ((void *)0));
   ht->total++;

   if ( ht->math <= (float)ht->unique )
      htRehash(hashTable);
   i = j = 0;
   i = ht->functions.hash(data) % ht->capacity;
   temp = ht->array[i];
   
   while ( temp )
   {
      comparedData = ht->functions.compare(temp->htEntry.data, data);
      if ( !comparedData )
      { 
         temp->htEntry.frequency++;
         return temp->htEntry.frequency;
      }
      temp = temp->next;
   }
   ht->unique++;
   ht->array[i] = addHead( ht->array[i], data );
   return 1;
}
void htRehash(void *hashTable)
{
   int i;
   ListNode ** array;
   HT * ht = hashTable;
   array = ht->array;
   ht->sizeIndex++;
   ht->array = calloc(ht->sizes[ht->sizeIndex], sizeof(ListNode*));
   for (i = 0; i < ht->capacity; i++)
   {
      if (array[i])
      {
         copyToArray( hashTable, array[i]);
      }
   }
   ht->capacity = ht->sizes[ht->sizeIndex];
   
   ( ht->sizeIndex == ht->numSizes - 1) ? (ht->math = FLT_MAX) : 
      (ht->math = ht->rehashLoadFactor * ht->capacity);
 
   free(array);
}

void copyToArray(void* hashTable, ListNode* temp)
{
   int index, cap;
   HT * ht = hashTable;
   ListNode * temp2;
   cap = ht->sizes[ht->sizeIndex];
   while (temp)
   {
      temp2 = temp->next;
      index = ht->functions.hash(temp->htEntry.data) % cap;
      temp->next = ht->array[index];
      ht->array[index] = temp;
      temp = temp2;     
   }
}

HTEntry htLookUp(void *hashTable, void *data)
{
   HTEntry ht_entry;
   int i;
   ListNode* temp;
   HT * ht = hashTable; 
   assert( data!=NULL );
   i =  ht->functions.hash(data) % ht->capacity;

   temp =  ht->array[i];
   while ( temp )
   {
      if (!ht->functions.compare(data, temp->htEntry.data) )
      {
         ht_entry = temp->htEntry;
         return ht_entry;
      }
      temp = temp->next;
   }
   ht_entry.frequency = 0;
   ht_entry.data = NULL;
   return ht_entry;
}

HTEntry* htToArray(void *hashTable, unsigned *size)
{
   int i, j;
   HT * ht = hashTable;
   HTEntry * ht_entry_ptr = NULL;
   ListNode* temp;
   if ( !ht->unique)
   {
      *size = 0;
      return ht_entry_ptr;
   }
   ht_entry_ptr = calloc( ht->unique , sizeof(HTEntry) );
   i = j = 0;
   for (; i < ht->capacity; i++) 
   {
      temp = ht->array[i];      
      while (temp)
      {
         ht_entry_ptr[j] = temp->htEntry;
         temp = temp->next;
         j++;
      }
   }
   *size = j;
   return ht_entry_ptr;
}

unsigned htCapacity(void *hashTable)
{
   return ((HT*)hashTable)->capacity;
}

unsigned htUniqueEntries(void *hashTable)
{
   return ((HT*)hashTable)->unique;
}

unsigned htTotalEntries(void *hashTable)
{
   return ((HT*)hashTable)->total;
}

HTMetrics htMetrics(void *hashTable)
{
   HTMetrics metrics;
   HT * ht = hashTable;
   ListNode* temp;
   int i, max, size;
   max = size = i = metrics.numberOfChains = 0;
   for (; i < ht->capacity ; i++)
   {
      temp = ht->array[i];
      if (temp)
      {
         metrics.numberOfChains++;
      }
      while ( temp )
      {         
         temp = temp->next;
         size++;
      }
      if (size > max)
      {
         max = size;
      }
      size = 0;        
   }
   (metrics.numberOfChains) ? (metrics.avgChainLength = ht->unique / 
      (float)metrics.numberOfChains) : (metrics.avgChainLength = 0);
   metrics.maxChainLength = max;   
   return metrics;
}
