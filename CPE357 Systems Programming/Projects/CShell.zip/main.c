#include "cshell.h"
#include <ctype.h>
int main(int argc, char**argv)
{
   char line[1025];
   Command command[20];
   setbuf(stdout, NULL);
   readCommand(command, line);
   exit(0);
}

void readCommand(Command* command, char* line)
{
   int qty=0;
   int ch=0;
   command[0].argv[0] = "0";
   while(ch!= EOF)
   {
      printf(":-) ");
      ch = readLine(line);      
      if (!ch || line[0]=='\n')
         continue;
      if ( ch==EOF)
         break;      
      qty = parseCommands(command, line);
      if(!strcmp(command[0].argv[0], "exit"))
         exit(0);
      execCommands(command, qty);      
   }
   printf("exit\n");
}

int parseCommands(Command* command, char* line)
{
   int i=0;
   char *token = NULL;

   while (line[i])
   {
      if (!isspace(line[i]));
         break;
      i++;
   }
   if (line[i]=='|')
   {
      fprintf(stderr, "cshell: Invalid pipe\n");
      return 0;  
   }
   i = 0;
   token = strtok(line, "|");
   do
   {
      if ( i > 19 )
      {
         fprintf(stderr, "cshell: Too many commands\n");
         return 0;
      }
      (token) ? (command[i].args = token) : (command[i].args = line);

      i++;
      
   } while ((token = strtok(NULL, "|")));
   if (!helpParse(command,line,i))
      return 0;
   return i;
}

int helpParse(Command* command, char* line, int i)
{
   int j =0, k=0;
   do
   {
      if (!(k=parseCommand(&command[j], command[j].args)))
      {
         fprintf(stderr, "cshell: Invalid pipe\n");
         return 0;  
      }
      else if (k==-1)
         return 0;
   } while (++j<i);
   return 1;
}

int parseCommand(Command* command, char* args)
{
   int i=0;
   char *token;
   command->in = command->out = NULL;
   token = strtok(args, " \n");
   do
   {
      if (!token)
         return 0;
      else if ( i > 10)
      {
         fprintf(stderr, "cshell: %s: Too many arguments\n", command->argv[0]);
         return -1;
      }
      else if (!strcmp(token, ">"))
      {
         command->out = strtok(NULL, " \n");
      }
      else if (!strcmp(token, "<"))
      {
         command->in = strtok(NULL, " \n");
      }
      else 
         command->argv[i++] = token;      
   } while ((token = strtok(NULL, " \n")));
   command->argv[i]=NULL;
   return 1;
}

int readLine(char* line )
{
   int ch = 0;
   int i=0;
   int b=0;
   while ((ch!=EOF) && (ch!='\n') && (i<1025))
   {
      ch=getchar();
      line[i++] = ch;
      if (!isspace(ch))
         b=1;
   }     
   if ( i>1024 )
   {
      if ( ch != '\n')
         clearBuffer();
      fprintf(stderr, "cshell: Command line too long\n");         
      return 0;
   }
   line[i]='\0';
   if(!b && ch!=EOF)
      return 0;
   return ch;
}

void clearBuffer()
{
   while(getchar() != '\n');
}
