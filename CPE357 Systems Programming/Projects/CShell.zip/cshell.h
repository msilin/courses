#ifndef CSHELL_H
#define CSHELL_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <signal.h>
#include <unistd.h>
#include <fcntl.h>

typedef struct
{
   char *argv[11];
   char *args;
   char *in, *out;
} Command;

int readLine(char* line);
void readCommand(Command* command, char *line);
int parseCommand(Command* command, char *args);
int parseCommands(Command* command, char *line);
void execChild(Command* command, int *fd, int qty, int i);
void execCommands(Command* command, int qty);
void newPipe(int* fd);
void clearBuffer();
void redirect(Command *command, int* fd, int* fp);
int helpParse(Command* command, char* line, int i);

#endif