#include "cshell.h"
#include <unistd.h>
void newPipe(int* fd)
{
   if (pipe(fd) == -1) {
      perror("pipe");
      exit(EXIT_FAILURE);
   }
}

void execCommands(Command* command, int qty)
{
   int i=0, fd[3];
   if (!qty)
      return;
   newPipe(fd);
   for (; i<qty; i++ )
   {
      if (i > 0)
      {  
         fd[2]=fd[0];
         close(fd[1]); 
         newPipe(fd);
      }
      execChild(command, fd, qty, i);
      close(fd[2]);
   }
   close(fd[0]);
   close(fd[1]);
   close(fd[2]);
   for(i=0; i<qty;i++)
      wait(NULL);
}

void pipeline(int i, int qty, int* fd)
{
   if ((i == 0) && (qty > 1))
      dup2(fd[1], STDOUT_FILENO);
   else if ((i == qty -1) )
      dup2(fd[2], STDIN_FILENO);
   else
   {
      dup2(fd[2], STDIN_FILENO);
      dup2(fd[1], STDOUT_FILENO);
   }
   close(fd[0]);
}

void redirect(Command *command, int* fp, int* fd)
{
   int flags;
   if ( command->in)
   {
      flags = O_RDONLY;
      if (-1 ==(*fp=open(command->in, flags, 0666 )))
      {
         fprintf(stderr, "cshell: Unable to open file for input\n");
         exit(EXIT_FAILURE);
      }
      dup2(*fp, STDIN_FILENO);
   }
   if (command->out)
   {
      flags = O_WRONLY | O_CREAT | O_TRUNC;
      if (-1 == (*fp=open(command->out, flags,0666 )))
      {
         fprintf(stderr, "cshell: Unable to open file for output\n");
         exit(EXIT_FAILURE);
      }
      dup2(*fp, STDOUT_FILENO);
   }
}

void execChild(Command *command, int *fd, int qty, int i)
{
   int fp=0;
   if ( fork()==0)
   {   
      pipeline(i, qty, fd);
      redirect(&command[i], &fp, fd);
      if (execvp(command[i].argv[0], command[i].argv) == -1)
      {
         close(fd[0]);
         close(fd[1]);
         fprintf(stderr, "cshell: %s: Command not found\n", command[i].argv[0]);
         exit(EXIT_FAILURE);
      }    
   }
   if (fp)
      close(fp);
}