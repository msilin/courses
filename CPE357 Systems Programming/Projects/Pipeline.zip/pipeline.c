#include <sys/wait.h>
#include <sys/types.h>
#include "string.h"
#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <unistd.h>
#include "launcher.h"

void newPipe(int* fd)
{
   if (pipe(fd) == -1) {
      perror("pipe");
      exit(EXIT_FAILURE);
   }
}

void spawnChildren( int*fd, int p, char** chld_args)
{
   char fd0[2] = "0", fd1[2];
   sprintf(fd0, "%d", fd[0]); /*convert fd0 flag to a string*/
   sprintf(fd1, "%d", fd[1]); /*convert fd1 flag to a string*/
   chld_args[6] = fd1;
   
   execChild( chld_args, fd);
   while ( p-- > 0)
   {
      if ( p == 1)
         chld_args[6] = "1"; 
      fd[2] = fd[0];
      close(fd[1]);
      pipe(fd);
      chld_args[4] = fd0;
      sprintf(fd1, "%d", fd[1]);
      execChild( chld_args, fd);
      sprintf(fd0, "%d", fd[0]);
      close(fd[2]);
   }
}

void execChild(char** chld_args, int*fd)
{
   if (fork()==0)
   {  
      close(fd[0]);              
      execv( chld_args[0], chld_args);
   }
}

void waitAndClose(int*fd, int p)
{
   int i = 0;
   for ( i = 0; i < p; i++)
   {
      wait(NULL);
   }
   close(fd[0]);
   close(fd[1]);
   close(fd[2]);    
}

int checkArgs(int argc, char** argv, int *c, int *p)
{
   int path_index, i = 1;
   for (; i<argc; i++)
   {
      if (!strcmp(argv[i], "-c") && (i != argc-1))
         sscanf(argv[++i], "%d", c);
      else if (!strcmp(argv[i], "-p")&& (i != argc-1))
         sscanf(argv[++i], "%d", p);
      else
         path_index = i;
   }
   if (( argc!=6) || (*p < 2)|| (*p > 10) || (*c < 1))
   {
      usageMessage();
   }
   return path_index;
}

void usageMessage()
{
   fprintf(stderr, "Usage: pipeline pathToRandomChild -c count -p processes"
      "\n");
   fprintf(stderr, "Where: count > 0 and processes is 2 to 10, inclusive\n");
   exit(EXIT_FAILURE);
}
