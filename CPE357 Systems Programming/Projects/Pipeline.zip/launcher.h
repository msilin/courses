#ifndef LAUNCHER_H
#define LAUNCHER_H
void newPipe(int* fd);
int checkArgs(int argc, char** argv, int *c, int *p);
void waitAndClose(int*fd, int p);
void usageMessage();
void spawnChildren( int*fd, int p, char** chld_args);
void execChild(char** chld_args, int*fd);
#endif