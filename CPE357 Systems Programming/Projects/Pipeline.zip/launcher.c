#include <stdio.h>
#include <stdlib.h>
#include "launcher.h"

int main(int argc, char**argv)
{
   int fd[3], c = 0, p = 0, chld_index;
   char c_arg[10];
   char *chld_args[8] = {
      NULL, 
      "-c",
      NULL,
      "-i",
      "0",
      "-o",
      NULL ,
      NULL
   };
   
   chld_index = checkArgs(argc, argv, &c, &p);
   newPipe(fd);
   sprintf(c_arg,  "%d", c);     /*convert -c  flag to a string*/
   chld_args[0] = argv[chld_index];
   chld_args[2] = c_arg;

   spawnChildren(fd, p, chld_args);
   waitAndClose(fd, p);
   exit(0);
}