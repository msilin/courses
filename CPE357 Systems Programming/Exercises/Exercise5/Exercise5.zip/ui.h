#ifndef UI_H /* Multiple inclusion guard */
#define UI_H /* Multiple inclusion guard */

#include "cuboid.h"

double getLength();
double getWidth();
double getHeight();

void showResults(Cuboid cuboid);
#endif
